import { connectToDatabase } from "./server/db";
import { UserModel, ConversationModel, MessageModel } from "./shared/schema";

async function seedDatabase() {
  await connectToDatabase();
  
  console.log("Seeding MongoDB database...");
  
  // Clear existing data
  await UserModel.deleteMany({});
  await ConversationModel.deleteMany({});
  await MessageModel.deleteMany({});
  
  // Create users
  const users = await UserModel.insertMany([
    {
      name: "Alice Johnson",
      phone: "+1234567890",
      wa_id: "1234567890",
      avatar: "https://ui-avatars.com/api/?name=Alice+Johnson&background=25d366&color=fff&size=128"
    },
    {
      name: "Bob Smith", 
      phone: "+1987654321",
      wa_id: "1987654321",
      avatar: "https://ui-avatars.com/api/?name=Bob+Smith&background=25d366&color=fff&size=128"
    },
    {
      name: "Carol Williams",
      phone: "+1122334455", 
      wa_id: "1122334455",
      avatar: "https://ui-avatars.com/api/?name=Carol+Williams&background=25d366&color=fff&size=128"
    }
  ]);
  
  console.log(`Created ${users.length} users`);
  
  // Create conversations
  const conversations = await ConversationModel.insertMany([
    {
      user_id: users[0]._id,
      lastMessage: "Hey! How are you doing?",
      lastMessageAt: new Date(),
      unreadCount: 2
    },
    {
      user_id: users[1]._id,
      lastMessage: "Thanks for the help yesterday",
      lastMessageAt: new Date(Date.now() - 1000 * 60 * 30),
      unreadCount: 0
    },
    {
      user_id: users[2]._id,
      lastMessage: "See you tomorrow!",
      lastMessageAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
      unreadCount: 1
    }
  ]);
  
  console.log(`Created ${conversations.length} conversations`);
  
  // Create messages
  const messages = await MessageModel.insertMany([
    {
      conversationId: conversations[0]._id,
      senderId: users[0]._id,
      text: "Hey! How are you doing?",
      status: "delivered",
      isFromMe: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 5)
    },
    {
      conversationId: conversations[0]._id,
      senderId: users[0]._id,
      text: "I wanted to catch up with you",
      status: "delivered",
      isFromMe: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 3)
    },
    {
      conversationId: conversations[1]._id,
      senderId: users[1]._id,
      text: "Thanks for the help yesterday",
      status: "read",
      isFromMe: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 30)
    },
    {
      conversationId: conversations[1]._id,
      senderId: users[1]._id,
      text: "Really appreciate it!",
      status: "read",
      isFromMe: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 25)
    },
    {
      conversationId: conversations[2]._id,
      senderId: users[2]._id,
      text: "See you tomorrow!",
      status: "sent",
      isFromMe: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2)
    }
  ]);
  
  console.log(`Created ${messages.length} messages`);
  console.log("Database seeded successfully!");
  
  process.exit(0);
}

seedDatabase().catch(console.error);