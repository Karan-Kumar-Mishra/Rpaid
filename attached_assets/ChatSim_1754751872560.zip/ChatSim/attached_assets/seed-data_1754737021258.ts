// Seed script to add sample WhatsApp conversation data
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "./shared/schema.ts";

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema });

async function seedData() {
  console.log('🌱 Seeding sample data...');

  try {
    // Create sample users
    const users = await db.insert(schema.users)
      .values([
        {
          wa_id: '1234567890',
          name: 'Alice Johnson',
          phone: '+1 (555) 123-4567',
          avatar: null
        },
        {
          wa_id: '0987654321',
          name: 'Bob Smith',
          phone: '+1 (555) 987-6543',
          avatar: null
        },
        {
          wa_id: '5555555555',
          name: 'Carol Williams',
          phone: '+1 (555) 555-5555',
          avatar: null
        },
        {
          wa_id: 'demo_user',
          name: 'You',
          phone: 'demo_user',
          avatar: null
        }
      ])
      .returning();

    console.log(`✓ Created ${users.length} users`);

    // Create conversations
    const conversations = await db.insert(schema.conversations)
      .values([
        {
          user_id: users[0].id, // Alice
          lastMessage: "Hey, how are you doing?",
          unreadCount: 2,
          lastMessageAt: new Date()
        },
        {
          user_id: users[1].id, // Bob
          lastMessage: "Thanks for the help yesterday!",
          unreadCount: 0,
          lastMessageAt: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
        },
        {
          user_id: users[2].id, // Carol
          lastMessage: "Did you see the new update?",
          unreadCount: 1,
          lastMessageAt: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
        }
      ])
      .returning();

    console.log(`✓ Created ${conversations.length} conversations`);

    // Create sample messages
    const messages = await db.insert(schema.messages)
      .values([
        // Alice conversation
        {
          conversationId: conversations[0].id,
          senderId: users[0].id,
          metaMsgId: 'msg_001',
          text: "Hi there! How's your day going?",
          type: 'text',
          status: 'delivered',
          isFromMe: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 60) // 1 hour ago
        },
        {
          conversationId: conversations[0].id,
          senderId: users[3].id, // You
          text: "Hey Alice! Going well, thanks for asking. How about you?",
          type: 'text',
          status: 'read',
          isFromMe: true,
          timestamp: new Date(Date.now() - 1000 * 60 * 45) // 45 minutes ago
        },
        {
          conversationId: conversations[0].id,
          senderId: users[0].id,
          metaMsgId: 'msg_002',
          text: "Pretty good! Working on some exciting projects.",
          type: 'text',
          status: 'delivered',
          isFromMe: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
        },
        {
          conversationId: conversations[0].id,
          senderId: users[0].id,
          metaMsgId: 'msg_003',
          text: "Hey, how are you doing?",
          type: 'text',
          status: 'delivered',
          isFromMe: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 5) // 5 minutes ago
        },

        // Bob conversation
        {
          conversationId: conversations[1].id,
          senderId: users[3].id, // You
          text: "No problem! Happy to help anytime.",
          type: 'text',
          status: 'read',
          isFromMe: true,
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3) // 3 hours ago
        },
        {
          conversationId: conversations[1].id,
          senderId: users[1].id,
          metaMsgId: 'msg_004',
          text: "Thanks for the help yesterday!",
          type: 'text',
          status: 'delivered',
          isFromMe: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
        },

        // Carol conversation
        {
          conversationId: conversations[2].id,
          senderId: users[2].id,
          metaMsgId: 'msg_005',
          text: "Did you see the new update?",
          type: 'text',
          status: 'delivered',
          isFromMe: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
        }
      ])
      .returning();

    console.log(`✓ Created ${messages.length} messages`);
    console.log('🎉 Database seeded successfully!');
    
  } catch (error) {
    console.error('❌ Error seeding data:', error);
  } finally {
    await pool.end();
  }
}

seedData();