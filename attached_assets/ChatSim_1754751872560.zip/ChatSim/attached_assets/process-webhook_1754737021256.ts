// Script to process the provided WhatsApp webhook JSON files
import { readFileSync } from 'fs';
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "./shared/schema.ts";
import { eq } from "drizzle-orm";

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema });

// Load JSON files
const webhookFiles = [
  'attached_assets/conversation_1_message_1_1754716882194.json',
  'attached_assets/conversation_1_message_2_1754716882197.json',
  'attached_assets/conversation_1_status_1_1754716882198.json',
  'attached_assets/conversation_1_status_2_1754716882199.json',
  'attached_assets/conversation_2_message_1_1754716882200.json',
  'attached_assets/conversation_2_message_2_1754716882201.json',
  'attached_assets/conversation_2_status_1_1754716882202.json',
  'attached_assets/conversation_2_status_2_1754716882203.json'
];

async function processWebhooks() {
  console.log('🔄 Processing WhatsApp webhook files...');

  try {
    for (const filePath of webhookFiles) {
      console.log(`\n📄 Processing ${filePath}...`);
      
      try {
        const fileContent = readFileSync(filePath, 'utf8');
        const webhookData = JSON.parse(fileContent);
        
        // Process the webhook payload
        await processWebhookPayload(webhookData);
        
      } catch (fileError) {
        console.error(`❌ Error processing file ${filePath}:`, fileError.message);
        continue;
      }
    }
    
    console.log('\n🎉 All webhook files processed successfully!');
    
  } catch (error) {
    console.error('❌ Error processing webhooks:', error);
  } finally {
    await pool.end();
  }
}

async function processWebhookPayload(payload: any) {
  if (!payload.metaData?.entry?.[0]?.changes?.[0]?.value) {
    console.log('⚠️  Skipping - No valid webhook data found');
    return;
  }

  const changeValue = payload.metaData.entry[0].changes[0].value;
  
  // Process messages
  if (changeValue.messages) {
    const messages = changeValue.messages;
    const contacts = changeValue.contacts || [];
    
    for (const message of messages) {
      const contact = contacts.find((c: any) => c.wa_id === message.from);
      
      // Create or get user
      let user = await db.select()
        .from(schema.users)
        .where(eq(schema.users.wa_id, message.from))
        .limit(1);
      
      if (user.length === 0) {
        const [newUser] = await db
          .insert(schema.users)
          .values({
            wa_id: message.from,
            name: contact?.profile?.name || `User ${message.from}`,
            phone: message.from,
            avatar: null
          })
          .returning();
        user = [newUser];
      }
      
      // Create or get conversation
      let conversation = await db.select()
        .from(schema.conversations)
        .where(eq(schema.conversations.user_id, user[0].id))
        .limit(1);
      
      if (conversation.length === 0) {
        const [newConversation] = await db
          .insert(schema.conversations)
          .values({
            user_id: user[0].id,
            lastMessage: message.text?.body || 'New message',
            unreadCount: 1
          })
          .returning();
        conversation = [newConversation];
      }
      
      // Create message
      const isFromMe = message.from === changeValue.metadata?.display_phone_number;
      
      const [newMessage] = await db
        .insert(schema.messages)
        .values({
          conversationId: conversation[0].id,
          senderId: user[0].id,
          metaMsgId: message.id,
          text: message.text?.body || '',
          type: message.type || 'text',
          status: 'delivered',
          isFromMe: isFromMe,
          timestamp: new Date(parseInt(message.timestamp) * 1000)
        })
        .returning();
      
      // Update conversation
      await db
        .update(schema.conversations)
        .set({
          lastMessage: message.text?.body || 'New message',
          lastMessageAt: new Date(parseInt(message.timestamp) * 1000),
          unreadCount: isFromMe ? 0 : (conversation[0].unreadCount || 0) + 1
        })
        .where(eq(schema.conversations.id, conversation[0].id));
      
      console.log(`✓ Processed message from ${contact?.profile?.name || message.from}`);
    }
  }
  
  // Process status updates
  if (changeValue.statuses) {
    const statuses = changeValue.statuses;
    
    for (const status of statuses) {
      await db
        .update(schema.messages)
        .set({ status: status.status })
        .where(eq(schema.messages.metaMsgId, status.id));
      
      console.log(`✓ Updated message status to ${status.status}`);
    }
  }
}

processWebhooks();