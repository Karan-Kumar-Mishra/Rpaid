import mongoose from 'mongoose';
import { UserModel, ConversationModel, MessageModel } from '@shared/schema';
import dontenv from "dotenv";

const MONGODB_URI = process.env.MONGODB_URI || "mongodb+srv://dilagow410:VGfngAWKyl5kDhFD@cluster0.x2rfp.mongodb.net/HostStream?retryWrites=true&w=majority&appName=Cluster0";

// Re-export models for easier imports
export const User = UserModel;
export const Conversation = ConversationModel;
export const Message = MessageModel;

export async function connectToDatabase() {
//  dontenv.config()
  try {
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
      console.log('Connected to MongoDB');
    }
    return mongoose.connection;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    throw error;
  }
}

export async function disconnectFromDatabase() {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}
