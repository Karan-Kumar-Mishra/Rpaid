import { User, Conversation, Message } from './db';

export async function seedSampleData() {
  try {
    // Clear existing data first
    await User.deleteMany({});
    await Conversation.deleteMany({});
    await Message.deleteMany({});
    
    console.log('Cleared existing data, seeding fresh WhatsApp webhook data...');

    // Process WhatsApp webhook data
    await processWhatsAppWebhookData();

    console.log('WhatsApp webhook data seeded successfully!');

  } catch (error) {
    console.error('Error seeding WhatsApp webhook data:', error);
  }
}

async function processWhatsAppWebhookData() {
  // Conversation 1: Ravi Kumar
  const raviUser = new User({
    wa_id: '919937320320',
    name: 'Ravi Kumar',
    phone: '+919937320320',
    avatar: 'https://ui-avatars.com/api/?name=Ravi+Kumar&background=25d366&color=fff&size=96'
  });
  await raviUser.save();

  const raviConversation = new Conversation({
    user_id: raviUser._id,
    lastMessage: "Hi Ravi! Sure, I'd be happy to help you with that. Could you tell me what you're looking for?",
    lastMessageAt: new Date(1754400020 * 1000),
    unreadCount: 0
  });
  await raviConversation.save();

  // Ravi's messages
  await Message.insertMany([
    {
      conversationId: raviConversation._id,
      senderId: raviUser._id,
      text: "Hi, I'd like to know more about your services.",
      timestamp: new Date(1754400000 * 1000),
      status: 'read',
      isFromMe: false,
      whatsappId: 'wamid.HBgMOTE5OTY3NTc4NzIwFQIAEhggMTIzQURFRjEyMzQ1Njc4OTA='
    },
    {
      conversationId: raviConversation._id,
      senderId: 'business_user',
      text: "Hi Ravi! Sure, I'd be happy to help you with that. Could you tell me what you're looking for?",
      timestamp: new Date(1754400020 * 1000),
      status: 'read',
      isFromMe: true,
      whatsappId: 'wamid.HBgMOTE5OTY3NTc4NzIwFQIAEhggNDc4NzZBQ0YxMjdCQ0VFOTk2NzA3MTI4RkZCNjYyMjc='
    }
  ]);

  // Conversation 2: Neha Joshi
  const nehaUser = new User({
    wa_id: '929967673820',
    name: 'Neha Joshi',
    phone: '+929967673820',
    avatar: 'https://ui-avatars.com/api/?name=Neha+Joshi&background=25d366&color=fff&size=96'
  });
  await nehaUser.save();

  const nehaConversation = new Conversation({
    user_id: nehaUser._id,
    lastMessage: "Hi Neha! Absolutely. We offer curated home decor pieces—are you looking for nameplates, wall art, or something else?",
    lastMessageAt: new Date(1754401030 * 1000),
    unreadCount: 1
  });
  await nehaConversation.save();

  // Neha's messages
  await Message.insertMany([
    {
      conversationId: nehaConversation._id,
      senderId: nehaUser._id,
      text: "Hi, I saw your ad. Can you share more details?",
      timestamp: new Date(1754401000 * 1000),
      status: 'sent',
      isFromMe: false,
      whatsappId: 'wamid.HBgMOTI5OTY3NjczODIwFQIAEhggQ0FBQkNERUYwMDFGRjEyMzQ1NkZGQTk5RTJCM0I2NzY='
    },
    {
      conversationId: nehaConversation._id,
      senderId: 'business_user',
      text: "Hi Neha! Absolutely. We offer curated home decor pieces—are you looking for nameplates, wall art, or something else?",
      timestamp: new Date(1754401030 * 1000),
      status: 'delivered',
      isFromMe: true,
      whatsappId: 'wamid.HBgMOTI5OTY3NjczODIwFQIAEhggM0RFNDkxRjEwNDhDQzgwMzk3NzA1ODc1RkU3QzI0MzU='
    }
  ]);

  console.log('Created conversations for Ravi Kumar and Neha Joshi with authentic WhatsApp data');
}