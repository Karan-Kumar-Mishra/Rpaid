import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { connectToDatabase } from "./db";
import { UserModel, ConversationModel, MessageModel, insertMessageSchema } from "@shared/schema";
import { processWebhookData } from "./webhookProcessor";

export async function registerRoutes(app: Express): Promise<Server> {
  // Connect to MongoDB
  await connectToDatabase();
  
  // Always seed fresh data for testing
  const { seedSampleData } = await import('./seedData');
  await seedSampleData();

  // API Routes
  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await ConversationModel.find()
        .populate('user_id', 'name phone avatar wa_id')
        .sort({ lastMessageAt: -1 });
      
      res.json(conversations);
    } catch (error) {
      console.error('Error fetching conversations:', error);
      res.status(500).json({ error: 'Failed to fetch conversations' });
    }
  });

  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const messages = await MessageModel.find({ conversationId: id })
        .populate('senderId', 'name avatar wa_id')
        .sort({ timestamp: 1 });
      
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertMessageSchema.parse({
        ...req.body,
        conversationId: id,
        isFromMe: true,
        status: 'sent'
      });

      const message = new MessageModel(validatedData);
      await message.save();
      await message.populate('senderId', 'name avatar wa_id');

      // Update conversation
      await ConversationModel.findByIdAndUpdate(id, {
        lastMessage: validatedData.text,
        lastMessageAt: new Date()
      });

      // Broadcast to WebSocket clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'new_message',
            data: message
          }));
        }
      });

      res.json(message);
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(500).json({ error: 'Failed to send message' });
    }
  });

  app.post("/api/webhook", async (req, res) => {
    try {
      await processWebhookData(req.body);
      
      // Broadcast conversation updates to WebSocket clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'conversation_updated'
          }));
        }
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error processing webhook:', error);
      res.status(500).json({ error: 'Failed to process webhook' });
    }
  });

  app.put("/api/messages/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      const message = await MessageModel.findByIdAndUpdate(
        id,
        { status },
        { new: true }
      ).populate('senderId', 'name avatar wa_id');

      // Broadcast status update to WebSocket clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'message_status_update',
            data: { messageId: id, status }
          }));
        }
      });

      res.json(message);
    } catch (error) {
      console.error('Error updating message status:', error);
      res.status(500).json({ error: 'Failed to update message status' });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection');

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'mark_as_read') {
          const { conversationId } = data;
          
          // Mark messages as read
          await MessageModel.updateMany(
            { conversationId, isFromMe: false, status: { $ne: 'read' } },
            { status: 'read' }
          );

          // Reset unread count
          await ConversationModel.findByIdAndUpdate(conversationId, {
            unreadCount: 0
          });

          // Broadcast to all clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'messages_read',
                data: { conversationId }
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  return httpServer;
}
