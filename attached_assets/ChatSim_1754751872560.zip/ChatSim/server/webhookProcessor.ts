import { User, Conversation, Message } from './db';
import type { WhatsAppWebhookData } from '@shared/schema';

export async function processWebhookData(webhookData: WhatsAppWebhookData): Promise<void> {
  try {
    console.log('Processing webhook data:', JSON.stringify(webhookData, null, 2));

    // Extract message data from webhook
    const entry = webhookData.entry?.[0];
    const changes = entry?.changes?.[0];
    const messages = changes?.value?.messages;
    const contacts = changes?.value?.contacts;

    if (!messages || !contacts) {
      console.log('No messages or contacts found in webhook data');
      return;
    }

    // Process each message
    for (const message of messages) {
      const contact = contacts.find((c: any) => c.wa_id === message.from);
      
      if (!contact) {
        console.log(`Contact not found for wa_id: ${message.from}`);
        continue;
      }

      // Create or update user
      let user = await User.findOne({ wa_id: message.from });
      if (!user) {
        user = new User({
          wa_id: message.from,
          name: contact.profile?.name || `User ${message.from}`,
          phone: message.from,
          avatar: contact.profile?.avatar || null
        });
        await user.save();
        console.log('Created new user:', user.name);
      }

      // Find or create conversation
      let conversation = await Conversation.findOne({ 
        user_id: user._id 
      });
      
      if (!conversation) {
        conversation = new Conversation({
          user_id: user._id,
          lastMessage: message.text?.body || 'Media message',
          lastMessageAt: new Date(parseInt(message.timestamp) * 1000),
          unreadCount: 1
        });
        await conversation.save();
        console.log('Created new conversation for:', user.name);
      } else {
        // Update existing conversation
        conversation.lastMessage = message.text?.body || 'Media message';
        conversation.lastMessageAt = new Date(parseInt(message.timestamp) * 1000);
        conversation.unreadCount = (conversation.unreadCount || 0) + 1;
        await conversation.save();
        console.log('Updated conversation for:', user.name);
      }

      // Create message
      const newMessage = new Message({
        conversationId: conversation._id,
        senderId: message.from,
        text: message.text?.body || 'Media message',
        timestamp: new Date(parseInt(message.timestamp) * 1000),
        status: 'delivered',
        type: message.type || 'text'
      });
      
      await newMessage.save();
      console.log('Created new message:', newMessage.text);

      // Here you could broadcast the new message via WebSocket
      // broadcastMessage(conversation._id, newMessage);
    }

    console.log('Webhook processing completed successfully');
  } catch (error) {
    console.error('Error processing webhook data:', error);
    throw error;
  }
}