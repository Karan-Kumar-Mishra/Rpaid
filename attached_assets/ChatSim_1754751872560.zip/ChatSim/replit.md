# WhatsApp Web Clone

## Overview

This is a full-stack WhatsApp Web clone built to replicate the real-time messaging interface. The application features a React frontend with shadcn/ui components that mirrors WhatsApp Web's design, an Express.js backend with WebSocket support for real-time messaging, and webhook processing capabilities for ingesting WhatsApp messages.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool for fast development and optimized production builds
- **UI Library**: shadcn/ui components built on Radix UI primitives, providing accessible and customizable interface elements with WhatsApp-inspired styling
- **Styling**: Tailwind CSS with CSS variables for theming, responsive design, and WhatsApp-specific color schemes
- **State Management**: TanStack Query (React Query) for server state management, caching, and data synchronization
- **Routing**: Wouter for lightweight client-side routing between chat conversations
- **Real-time Updates**: Custom WebSocket manager with automatic reconnection logic and exponential backoff for handling live message updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript with ES modules for type safety and modern JavaScript features
- **API Design**: RESTful endpoints for conversations, messages, and webhook processing with proper error handling
- **Real-time Communication**: WebSocket server using the `ws` library integrated with the HTTP server for bi-directional communication
- **Session Management**: Express sessions with PostgreSQL session storage using connect-pg-simple

### Data Storage Solutions
- **Database**: PostgreSQL using Neon serverless database for scalable cloud hosting
- **ORM**: Drizzle ORM with Drizzle Kit for type-safe database operations and schema migrations
- **Schema Design**: Normalized relational structure with three core entities:
  - Users table storing WhatsApp profiles with unique wa_id identifiers
  - Conversations table linking users with metadata like last message and unread counts
  - Messages table with content, status tracking, sender relationships, and foreign key constraints
- **Migration Strategy**: Database schema managed through Drizzle migrations with version control

### Authentication and Authorization
- **Session-based Authentication**: Express sessions stored in PostgreSQL for persistence across server restarts
- **Webhook-based Design**: System designed for ingesting messages through WhatsApp webhook payloads rather than traditional user authentication
- **Demo User Support**: Includes demo user functionality for testing and development

### Real-time Communication
- **WebSocket Integration**: WebSocket server runs alongside HTTP server on the same port with automatic client reconnection
- **Message Broadcasting**: Real-time message delivery to connected clients with status updates
- **Connection Management**: Handles client disconnections gracefully with automatic reconnection attempts and exponential backoff

### Webhook Processing
- **WhatsApp Integration**: Processes incoming webhook payloads from WhatsApp Business API
- **Message Ingestion**: Automatically creates users, conversations, and messages from webhook data
- **Status Updates**: Handles message delivery and read status updates through webhook notifications