import { Check, CheckCheck } from "lucide-react";
import type { Message } from "@shared/schema";

interface MessageBubbleProps {
  message: Message;
  isConsecutive?: boolean;
}

export default function MessageBubble({ message, isConsecutive = false }: MessageBubbleProps) {
  const isOwn = message.isFromMe || message.senderId === "business_user" || message.senderId === "demo_user";
  
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusIcon = () => {
    if (!isOwn) return null;
    
    switch (message.status) {
      case 'sent':
        return <Check size={16} className="text-whatsapp-text-tertiary opacity-70" />;
      case 'delivered':
        return <CheckCheck size={16} className="text-whatsapp-text-tertiary opacity-70" />;
      case 'read':
        return <CheckCheck size={16} className="text-blue-400" />;
      default:
        return null;
    }
  };

  return (
    <div
      className={`flex items-end mb-1 ${
        isConsecutive ? 'mb-1' : 'mb-2'
      } ${isOwn ? 'justify-end' : 'justify-start'}`}
      data-testid={`message-${message._id}`}
    >
      {/* Message Bubble */}
      <div className={`max-w-[65%] ${isOwn ? 'ml-auto' : 'mr-auto'}`}>
        <div
          className={`relative px-3 py-2 rounded-lg shadow-sm ${
            isOwn
              ? 'bg-whatsapp-sent-bubble text-gray-800'
              : 'bg-whatsapp-received-bubble text-whatsapp-text-primary'
          } ${
            isConsecutive
              ? isOwn
                ? 'rounded-br-sm'
                : 'rounded-bl-sm'
              : isOwn
                ? 'rounded-br-md'
                : 'rounded-bl-md'
          }`}
          data-testid={`bubble-${message._id}`}
        >
          {/* Message tail/pointer */}
          {!isConsecutive && (
            <div
              className={`absolute ${
                isOwn
                  ? 'right-[-6px] bottom-0 border-l-[6px] border-l-whatsapp-sent-bubble border-b-[6px] border-b-transparent'
                  : 'left-[-6px] bottom-0 border-r-[6px] border-r-whatsapp-received-bubble border-b-[6px] border-b-transparent'
              }`}
            />
          )}

          {/* Message Content */}
          <p className="text-sm leading-relaxed break-words whitespace-pre-wrap" data-testid={`text-${message._id}`}>
            {message.text}
          </p>
          
          {/* Time and Status */}
          <div className={`flex items-center justify-end mt-1 space-x-1 ${
            isOwn ? 'text-gray-600' : 'text-whatsapp-text-tertiary'
          }`}>
            <span className="text-xs opacity-75" data-testid={`time-${message._id}`}>
              {formatTime(message.timestamp)}
            </span>
            {getStatusIcon()}
          </div>
        </div>
      </div>
    </div>
  );
}