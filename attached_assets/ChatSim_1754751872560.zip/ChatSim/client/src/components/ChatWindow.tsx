import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Video, Phone, Search, MoreVertical, Smile, Paperclip, Mic, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import MessageBubble from "./MessageBubble";
import { useWebSocket } from "@/hooks/useWebSocket";
import { apiRequest } from "@/lib/api";
import type { Message, Conversation } from "@shared/schema";

interface ChatWindowProps {
  conversationId: string;
  onBackToList: () => void;
  showBackButton: boolean;
}

export default function ChatWindow({ conversationId, onBackToList, showBackButton }: ChatWindowProps) {
  const [messageText, setMessageText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const { socket, isConnected } = useWebSocket();

  const { data: conversation } = useQuery<Conversation>({
    queryKey: ["/api/conversations", conversationId],
    enabled: !!conversationId,
  });

  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/conversations", conversationId, "messages"],
    enabled: !!conversationId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest("POST", `/api/conversations/${conversationId}/messages`, {
        text,
        senderId: "demo_user",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/conversations", conversationId, "messages"]
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/conversations"]
      });
      setMessageText("");
      scrollToBottom();
    },
  });

  const markAsReadMutation = useMutation({
    mutationFn: async () => {
      if (socket && isConnected) {
        socket.send(JSON.stringify({
          type: 'mark_as_read',
          conversationId
        }));
      }
    },
  });

  useEffect(() => {
    if (conversationId && conversation && (conversation.unreadCount || 0) > 0) {
      markAsReadMutation.mutate();
    }
  }, [conversationId, conversation]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = () => {
    if (messageText.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(messageText.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!conversationId) {
    return (
      <div className="flex-1 bg-whatsapp-background flex items-center justify-center chat-background">
        <div className="text-center text-whatsapp-text-secondary max-w-md px-8">
          <div className="text-8xl mb-6 opacity-20">💬</div>
          <h2 className="text-2xl font-light mb-4 text-whatsapp-text-primary">WhatsApp Web</h2>
          <p className="text-lg mb-2">
            Send and receive messages without keeping your phone online.
          </p>
          <p className="text-sm opacity-75">
            Use WhatsApp on up to 4 linked devices and 1 phone at the same time.
          </p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 bg-whatsapp-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-whatsapp-active"></div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-screen bg-whatsapp-background">
      {/* Chat Header */}
      <div className="bg-whatsapp-chat-header px-4 py-3 border-b border-whatsapp-border flex items-center">
        {/* Back Button (Mobile) */}
        {showBackButton && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackToList}
            className="mr-2 p-2 hover:bg-whatsapp-hover text-whatsapp-text-primary lg:hidden"
            data-testid="button-back"
          >
            <ArrowLeft size={20} />
          </Button>
        )}

        {/* Contact Info */}
        <div className="flex items-center flex-1 min-w-0">
          <img
            src={conversation?.user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(conversation?.user?.name || 'User')}&background=25d366&color=fff&size=40`}
            alt={conversation?.user?.name || 'User'}
            className="w-10 h-10 rounded-full mr-3"
            data-testid="contact-avatar"
          />
          <div className="flex-1 min-w-0">
            <h2 className="font-medium text-whatsapp-text-primary truncate" data-testid="contact-name">
              {conversation?.user?.name || 'Unknown User'}
            </h2>
            <p className="text-sm text-whatsapp-text-secondary">
              {isConnected ? 'online' : 'connecting...'}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2 ml-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
            data-testid="button-video-call"
          >
            <Video size={20} />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
            data-testid="button-voice-call"
          >
            <Phone size={20} />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
            data-testid="button-search"
          >
            <Search size={20} />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
            data-testid="button-more"
          >
            <MoreVertical size={20} />
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4 chat-background whatsapp-scrollbar">
        <div className="space-y-1">
          {messages?.map((message, index) => {
            const isConsecutive = index > 0 && 
              messages[index - 1].senderId === message.senderId &&
              new Date(message.timestamp).getTime() - new Date(messages[index - 1].timestamp).getTime() < 60000; // Within 1 minute
            
            return (
              <MessageBubble
                key={message._id}
                message={message}
                isConsecutive={isConsecutive}
              />
            );
          })}
        </div>
        <div ref={messagesEndRef} />
      </ScrollArea>

      {/* Message Input */}
      <div className="bg-whatsapp-chat-header px-4 py-3 border-t border-whatsapp-border text-wh">
        <div className="flex items-end space-x-2">
          {/* Emoji Button */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary flex-shrink-0"
            data-testid="button-emoji"
          >
            <Smile size={20} />
          </Button>

          {/* Attachment Button */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary flex-shrink-0"
            data-testid="button-attachment"
          >
            <Paperclip size={20} />
          </Button>

          {/* Message Input */}
          <div className="flex-1 relative">
            <Input
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message"
              className="bg-whatsapp-input border-whatsapp-border text-whatsapp-text-primary placeholder-whatsapp-text-tertiary focus:ring-whatsapp-active focus:border-whatsapp-active rounded-lg pr-12"
              disabled={sendMessageMutation.isPending}
              data-testid="input-message"
            />
          </div>

          {/* Send/Mic Button */}
          {messageText.trim() ? (
            <Button 
              onClick={handleSendMessage}
              disabled={sendMessageMutation.isPending}
              size="sm" 
              className="p-2 bg-whatsapp-active hover:bg-whatsapp-active/90 text-white flex-shrink-0 rounded-full"
              data-testid="button-send"
            >
              <Send size={20} />
            </Button>
          ) : (
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary flex-shrink-0"
              data-testid="button-mic"
            >
              <Mic size={20} />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}