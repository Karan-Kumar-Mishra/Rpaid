import { useState, useEffect } from "react";
import { useMediaQuery } from "@/hooks/use-mobile";
import ChatList from "./ChatList";
import ChatWindow from "./ChatWindow";
import { MessageCircle, Users, BellRing, Settings } from "lucide-react";

interface ChatLayoutProps {
  selectedConversationId: string | null;
  onConversationSelect: (conversationId: string) => void;
  onBackToList: () => void;
  showBackButton: boolean;
}

export default function ChatLayout({ 
  selectedConversationId, 
  onConversationSelect, 
  onBackToList, 
  showBackButton 
}: ChatLayoutProps) {
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [showChatList, setShowChatList] = useState(true);

  useEffect(() => {
    if (selectedConversationId && isMobile) {
      setShowChatList(false);
    } else if (!selectedConversationId && isMobile) {
      setShowChatList(true);
    }
  }, [selectedConversationId, isMobile]);

  const handleConversationSelect = (conversationId: string) => {
    onConversationSelect(conversationId);
    if (isMobile) {
      setShowChatList(false);
    }
  };

  const handleBackToList = () => {
    setShowChatList(true);
    onBackToList();
  };

  return (
    <div className="flex h-screen bg-whatsapp-dark text-whatsapp-text-primary font-whatsapp w-screen ">
      {/* Left Sidebar - Desktop Navigation */}
      <div className="hidden lg:flex flex-col w-16 bg-whatsapp-sidebar border-r border-whatsapp-border ">
        {/* User Profile Avatar */}
        <div className="p-4 border-b border-whatsapp-border">
          <img 
            src="https://ui-avatars.com/api/?name=You&background=25d366&color=fff&size=32" 
            alt="User Profile" 
            className="w-8 h-8 rounded-full"
            data-testid="user-avatar"
          />
        </div>
        
        {/* Navigation Icons */}
        <div className="flex-1 flex flex-col py-2">
          <button 
            className="p-4 hover:bg-whatsapp-hover transition-colors duration-200 group" 
            title="Chats"
            data-testid="nav-chats"
          >
            <MessageCircle className="text-whatsapp-text-secondary group-hover:text-whatsapp-text-primary" size={20} />
          </button>
          <button 
            className="p-4 hover:bg-whatsapp-hover transition-colors duration-200 group" 
            title="Communities"
            data-testid="nav-communities"
          >
            <Users className="text-whatsapp-text-secondary group-hover:text-whatsapp-text-primary" size={20} />
          </button>
          <button 
            className="p-4 hover:bg-whatsapp-hover transition-colors duration-200 group" 
            title="Channels"
            data-testid="nav-channels"
          >
            <BellRing className="text-whatsapp-text-secondary group-hover:text-whatsapp-text-primary" size={20} />
          </button>
        </div>
        
        {/* Settings */}
        <div className="p-4 border-t border-whatsapp-border">
          <button 
            className="hover:bg-whatsapp-hover p-2 rounded transition-colors duration-200 group" 
            title="Settings"
            data-testid="nav-settings"
          >
            <Settings className="text-whatsapp-text-secondary group-hover:text-whatsapp-text-primary" size={20} />
          </button>
        </div>
      </div>

      {/* Chat List */}
      {(showChatList || !isMobile) && (
        <div className="w-full lg:w-96 bg-whatsapp-sidebar flex flex-col border-r border-whatsapp-border">
          <ChatList 
            onConversationSelect={handleConversationSelect}
            selectedConversationId={selectedConversationId}
          />
        </div>
      )}

      {/* Chat Window or Empty State */}
      {(!showChatList || !isMobile) && (
        <div className="flex-1 flex flex-col bg-whatsapp-dark relative">
          {selectedConversationId ? (
            <ChatWindow 
              conversationId={selectedConversationId}
              onBackToList={handleBackToList}
              showBackButton={showBackButton}
            />
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8" data-testid="empty-state">
              <div className="w-64 h-64 mb-8 opacity-10">
                <MessageCircle className="w-full h-full text-whatsapp-text-secondary" />
              </div>
              <h2 className="text-2xl font-light text-whatsapp-text-primary mb-4">WhatsApp Web</h2>
              <p className="text-whatsapp-text-secondary mb-6 max-w-md">
                Send and receive messages without keeping your phone online.<br />
                Use WhatsApp on up to 4 linked devices and 1 phone at the same time.
              </p>
              <div className="flex items-center text-whatsapp-text-secondary text-sm">
                <span className="mr-2">🔒</span>
                <span>Your personal messages are end-to-end encrypted</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
