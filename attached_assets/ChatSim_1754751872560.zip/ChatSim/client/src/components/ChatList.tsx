import { useQuery } from "@tanstack/react-query";
import { Search, Plus, MoreVertical } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Conversation } from "@shared/schema";

interface ChatListProps {
  selectedConversationId: string | null;
  onConversationSelect: (conversationId: string) => void;
}

export default function ChatList({ selectedConversationId, onConversationSelect }: ChatListProps) {
  const { data: conversations, isLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const formatTime = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInHours = (now.getTime() - messageDate.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 24 * 7) {
      return messageDate.toLocaleDateString([], { weekday: 'short' });
    } else {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 bg-whatsapp-sidebar">
        <div className="p-4 border-b border-whatsapp-border">
          <div className="animate-pulse h-6 bg-whatsapp-hover rounded"></div>
        </div>
        <div className="p-4 space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse flex space-x-3">
              <div className="rounded-full bg-whatsapp-hover h-12 w-12"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-whatsapp-hover rounded w-3/4"></div>
                <div className="h-3 bg-whatsapp-hover rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-whatsapp-sidebar flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-whatsapp-border bg-whatsapp-chat-header">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-semibold text-whatsapp-text-primary" data-testid="chats-title">
            Chats
          </h1>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
              data-testid="button-new-chat"
            >
              <Plus size={20} />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2 hover:bg-whatsapp-hover text-whatsapp-text-secondary"
              data-testid="button-more-options"
            >
              <MoreVertical size={20} />
            </Button>
          </div>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 " size={16} />
          <Input
            placeholder="Search or start new chat"
            className="pl-10 bg-neutral-600 border-2 "
            data-testid="input-search"
          />
        </div>
      </div>

      {/* Conversation List */}
      <ScrollArea className="flex-1 whatsapp-scrollbar">
        <div className="divide-y divide-whatsapp-border">
          {conversations?.map((conversation) => (
            <div
              key={conversation._id}
              onClick={() => onConversationSelect(conversation._id)}
              className={`flex items-center p-4 hover:bg-whatsapp-hover cursor-pointer transition-colors duration-150 ${
                selectedConversationId === conversation._id ? 'bg-whatsapp-hover' : ''
              }`}
              data-testid={`conversation-${conversation._id}`}
            >
              {/* Avatar */}
              <div className="relative mr-3 flex-shrink-0">
                <img
                  src={conversation.user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(conversation.user?.name || 'User')}&background=25d366&color=fff&size=48`}
                  alt={conversation.user?.name || 'User'}
                  className="w-12 h-12 rounded-full object-cover"
                  data-testid={`avatar-${conversation._id}`}
                />
                {conversation.unreadCount > 0 && (
                  <div className="absolute -top-1 -right-1 bg-whatsapp-active text-white text-xs rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                    {conversation.unreadCount > 99 ? '99+' : conversation.unreadCount}
                  </div>
                )}
              </div>

              {/* Conversation Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-medium text-whatsapp-text-primary truncate" data-testid={`name-${conversation._id}`}>
                    {conversation.user?.name || 'Unknown User'}
                  </h3>
                  <span className="text-xs text-whatsapp-text-tertiary flex-shrink-0" data-testid={`time-${conversation._id}`}>
                    {formatTime(conversation.lastMessageAt)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-whatsapp-text-secondary truncate pr-2" data-testid={`message-${conversation._id}`}>
                    {conversation.lastMessage || 'No messages yet'}
                  </p>
                  {conversation.unreadCount > 0 && (
                    <div className="flex-shrink-0">
                      <div className="w-2 h-2 bg-whatsapp-active rounded-full"></div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {conversations?.length === 0 && (
          <div className="flex flex-col items-center justify-center h-64 text-whatsapp-text-secondary">
            <div className="text-6xl mb-4">💬</div>
            <h3 className="text-lg font-medium mb-2">No conversations yet</h3>
            <p className="text-sm text-center px-8">
              Your conversations will appear here when you start chatting
            </p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}