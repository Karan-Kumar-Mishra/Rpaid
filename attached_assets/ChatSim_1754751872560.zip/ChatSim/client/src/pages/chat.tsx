import { useState } from "react";
import { useLocation } from "wouter";
import { useMediaQuery } from "@/hooks/use-mobile";
import ChatLayout from "@/components/ChatLayout";

export default function ChatPage() {
  const [location, setLocation] = useLocation();
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const isMobile = useMediaQuery("(max-width: 768px)");

  // Extract conversation ID from URL if present
  const conversationIdFromUrl = location.startsWith('/chat/') 
    ? location.replace('/chat/', '') 
    : null;

  // Use URL conversation ID if available, otherwise use state
  const activeConversationId = conversationIdFromUrl || selectedConversationId;

  const handleConversationSelect = (conversationId: string) => {
    setSelectedConversationId(conversationId);
    if (isMobile) {
      setLocation(`/chat/${conversationId}`);
    }
  };

  const handleBackToList = () => {
    setSelectedConversationId(null);
    setLocation('/');
  };

  return (
    <div className="h-screen flex bg-whatsapp-background" data-testid="chat-page">
      <ChatLayout
        selectedConversationId={activeConversationId}
        onConversationSelect={handleConversationSelect}
        onBackToList={handleBackToList}
        showBackButton={isMobile}
      />
    </div>
  );
}