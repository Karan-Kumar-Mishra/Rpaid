import mongoose from 'mongoose';
import { z } from 'zod';

// User Schema
const userSchema = new mongoose.Schema({
  wa_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  phone: { type: String, required: true },
  avatar: { type: String, default: null },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Conversation Schema
const conversationSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  lastMessage: { type: String, default: '' },
  lastMessageAt: { type: Date, default: Date.now },
  unreadCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Message Schema
const messageSchema = new mongoose.Schema({
  conversationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Conversation', required: true },
  senderId: { type: String, required: true }, // Can be User ObjectId or business phone number
  metaMsgId: { type: String, default: null },
  whatsappId: { type: String, default: null },
  text: { type: String, required: true },
  type: { type: String, default: 'text' },
  status: { type: String, enum: ['sent', 'delivered', 'read'], default: 'sent' },
  isFromMe: { type: Boolean, default: false },
  timestamp: { type: Date, default: Date.now }
});

// Create Models
export const UserModel = mongoose.model('User', userSchema);
export const ConversationModel = mongoose.model('Conversation', conversationSchema);
export const MessageModel = mongoose.model('Message', messageSchema);

// Zod schemas for validation
export const insertUserSchema = z.object({
  wa_id: z.string(),
  name: z.string(),
  phone: z.string(),
  avatar: z.string().optional()
});

export const insertConversationSchema = z.object({
  user_id: z.string(),
  lastMessage: z.string().optional(),
  unreadCount: z.number().optional()
});

export const insertMessageSchema = z.object({
  conversationId: z.string(),
  senderId: z.string(),
  metaMsgId: z.string().optional(),
  text: z.string(),
  type: z.string().optional(),
  status: z.enum(['sent', 'delivered', 'read']).optional(),
  isFromMe: z.boolean().optional()
});

// TypeScript types
export type User = {
  _id: string;
  wa_id: string;
  name: string;
  phone: string;
  avatar?: string;
  createdAt: Date;
  updatedAt: Date;
};

export type Conversation = {
  _id: string;
  user_id: string;
  user?: User;
  lastMessage: string;
  lastMessageAt: Date;
  unreadCount: number;
  createdAt: Date;
  updatedAt: Date;
};

export type Message = {
  _id: string;
  conversationId: string;
  senderId: string;
  sender?: User;
  metaMsgId?: string;
  text: string;
  type: string;
  status: 'sent' | 'delivered' | 'read';
  isFromMe: boolean;
  timestamp: Date;
};

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

// WhatsApp Webhook Data Types
export interface WhatsAppWebhookData {
  object?: string;
  entry?: Array<{
    id?: string;
    changes?: Array<{
      value?: {
        messages?: Array<{
          from: string;
          id: string;
          timestamp: string;
          text?: {
            body: string;
          };
          type?: string;
        }>;
        contacts?: Array<{
          wa_id: string;
          profile?: {
            name?: string;
            avatar?: string;
          };
        }>;
      };
      field?: string;
    }>;
  }>;
}
